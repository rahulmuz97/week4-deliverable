package com.tests.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.scuba.helper.BrowserFactory;
//import com.scuba.helper.ExtentReportManager;
import com.tests.pages.LoginPageNew;

public class LoginPage_PF {
	
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static ExtentSparkReporter htmlReporter;
	
	@BeforeMethod
	public void setUp() {
		System.out.println(System.getProperty("user.dir"));
	    //extent = ExtentReportManager.getReports();
	    logger = extent.createTest("Login Test");
	}
	
	@Test
	public void TestValidLoginForChrome() throws Exception
	{		
		logger.log(Status.INFO, "Starting execution of test case");
		// calling start browser from browser factory		
		WebDriver driver = BrowserFactory.StartBrowser("chrome", "https://opensource-demo.orangehrmlive.com");	
		logger.log(Status.INFO, "Started the browser");
		LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);	
		logger.pass("Navigated to HRM website login page");
		login_page.loginHRM_New("Admin", "admin123");
		logger.pass("Login to HRM completed");
		driver.quit();
		logger.pass("Completed the test case");	
	}	
	
	@AfterMethod
	public void tearDown() {
		extent.flush();
	}
}
