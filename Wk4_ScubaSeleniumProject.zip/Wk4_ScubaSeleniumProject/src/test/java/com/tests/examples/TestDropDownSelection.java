package com.tests.examples;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
// soft assert import
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.scuba.helper.BrowserFactory;
import com.scuba.helper.ExtentReportManager;
import com.scuba.helper.WebUtils;
import com.tests.pages.LoginPageNew;

public class TestDropDownSelection {

	public static ExtentReports extent;
	public static ExtentTest test;
	public static ExtentSparkReporter spark;

	@BeforeMethod
	public void setUp() {
		extent = ExtentReportManager.getReports();
	}

	@Test
	@Parameters({ "browser", "testname" })
	public void DropDownTest1(String browser, String testname) throws IOException, InterruptedException {
		test = extent.createTest(testname);
		test.log(Status.INFO, "Starting execution of chrome test case");
		// calling start browser from browser factory
		WebDriver driver = BrowserFactory.StartBrowser(browser, "http://demo.guru99.com/test/newtours/register.php");
		test.log(Status.INFO, "Started the browser");
		WebUtils.takeSnapshot(driver, "target/screenshots/test1.png");
		// Select from dropdown ALGERIA - Select By Visible Test
		Select drpCountry = new Select(driver.findElement(By.name("country")));
		drpCountry.selectByVisibleText("ALGERIA");
		WebUtils.takeSnapshot(driver, "target/screenshots/dropdown1.png");
        Thread.sleep(5000);
        // Select By Value
        drpCountry.selectByValue("ASHMORE AND CARTIER ISLANDS");
		WebUtils.takeSnapshot(driver, "target/screenshots/dropdown2.png");
        Thread.sleep(5000);
     // Select By Index
        drpCountry.selectByIndex(4);
		WebUtils.takeSnapshot(driver, "target/screenshots/dropdown3.png");
        Thread.sleep(5000);
      //Selecting Items in a Multiple SELECT elements
  		driver.get("http://jsbin.com/osebed/2");
  		Thread.sleep(2000);
  		Select fruits = new Select(driver.findElement(By.id("fruits")));
  		fruits.selectByVisibleText("Banana");
  		fruits.selectByIndex(1);
  		List<WebElement> SelectedItems = fruits.getAllSelectedOptions();
  		System.out.println(SelectedItems.size());
  		Thread.sleep(3000);
  		fruits.deselectAll();
  		Thread.sleep(3000);
  		fruits.selectByVisibleText("Orange");
  		fruits.selectByVisibleText("Grape");
  		Thread.sleep(3000);
        driver.quit();
		
	}

	@Test(enabled = true)
	public void DropDownTest2() throws InterruptedException{
		WebDriver driver = BrowserFactory.StartBrowser("chrome", "https://www.sugarcrm.com/au/request-demo/");
		Select ddown = new Select(driver.findElement(By.name("employees_c")));
		ddown.selectByVisibleText("1 - 10 employees");
		Thread.sleep(3000);
		ddown.selectByValue("level4");
		Thread.sleep(3000);
		ddown.selectByIndex(8);
		Thread.sleep(5000);
		driver.quit();
	}
	
	@AfterMethod
	public void tearDown() {
		extent.flush(); // Instruct extent reports to write the test info to the destination
	}
}
