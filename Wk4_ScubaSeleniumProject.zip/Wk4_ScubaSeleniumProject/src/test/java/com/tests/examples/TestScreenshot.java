package com.tests.examples;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.scuba.helper.BrowserFactory;
import com.scuba.helper.ExtentReportManager;
import com.scuba.helper.WebUtils;
import com.tests.pages.LoginPageNew;

	public class TestScreenshot {
		
		public static ExtentReports extent;
		public static ExtentTest test;
		public static ExtentSparkReporter spark;
		
		@BeforeMethod
		public void setUp() {	
			extent = ExtentReportManager.getReports();	
		}

		@Test
		@Parameters({ "browser" , "testname"})
		public void ScreenshotTest(String browser, String testname) throws IOException {
			test = extent.createTest(testname);	
			test.log(Status.INFO, "Starting execution of chrome test case");
			// calling start browser from browser factory		
			WebDriver driver = BrowserFactory.StartBrowser(browser, "https://opensource-demo.orangehrmlive.com");	
			test.log(Status.INFO, "Started the browser");
			WebUtils.takeSnapshot(driver, "target/screenshots/test1.png");
			LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);	
			test.pass("Navigated to HRM website login page");
			test.log(Status.INFO, "Entering user credentials");
			login_page.loginHRM_New("Admin", "admin123");
			WebUtils.takeSnapshot(driver, "target/screenshots/test2.png");
			String ActualTitle = driver.getTitle();
			String ExpectedTitle = "OrangeHRM";
			Assert.assertEquals(ActualTitle, ExpectedTitle);
			test.pass("Login to HRM PASS");
			driver.quit();
			test.pass("Completed the chrome test case");		
		}
		
		@AfterMethod
		public void tearDown() {
			extent.flush(); // Instruct extent reports to write the test info to the destination
		}
	}

