package com.tests.examples;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
// soft assert import
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.scuba.helper.BrowserFactory;
import com.scuba.helper.ExtentReportManager;
import com.scuba.helper.WebUtils;
import com.tests.pages.LoginPageNew;

public class TestAssertions {

	public static ExtentReports extent;
	public static ExtentTest test;
	public static ExtentSparkReporter spark;

	@BeforeMethod
	public void setUp() {
		extent = ExtentReportManager.getReports();
	}

	@Test
	@Parameters({ "browser", "testname" })
	public void HardAssertionTest(String browser, String testname) throws IOException {
		test = extent.createTest(testname);
		test.log(Status.INFO, "Starting execution of chrome test case");
		// calling start browser from browser factory
		WebDriver driver = BrowserFactory.StartBrowser(browser, "https://opensource-demo.orangehrmlive.com");
		test.log(Status.INFO, "Started the browser");
		WebUtils.takeSnapshot(driver, "target/screenshots/test1.png");
		LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);
		test.pass("Navigated to HRM website login page");
		test.log(Status.INFO, "Entering user credentials");
		login_page.loginHRM_New("Admin", "admin123");
		WebUtils.takeSnapshot(driver, "target/screenshots/test2.png");
		// Hard Assertions
		// assertEquals
		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "OrangeHRM";
		Assert.assertEquals(ActualTitle, ExpectedTitle);
		// assertNotEquals
		String ActualTitle1 = "AppleHRM";
		String ExpectedTitle1 = "OrangeHRM";
		Assert.assertNotEquals(ActualTitle1, ExpectedTitle1);
		// assertTrue
		Boolean verifyTitle = driver.getTitle().equalsIgnoreCase("OrangeHRM");
		System.out.println("Boolean value of verifyTitle===: " + verifyTitle);
		Assert.assertTrue(verifyTitle);
		// assertFalse
		Boolean verifyTitle2 = driver.getTitle().equalsIgnoreCase("AppleHRM");
		System.out.println("Boolean value of verifyTitle===: " + verifyTitle2);
		Assert.assertTrue(verifyTitle2);
		// assertNull
		String verifyAssertNull = null;
		Assert.assertNull(verifyAssertNull);
		// assertNotNull
		Assert.assertNotNull(verifyAssertNull);
		test.pass("Login to HRM PASS");
		driver.quit();
		test.pass("Completed the chrome test case");
	}

	@Test
	@Parameters({ "browser", "testname" })
	public void SoftAssertionTest(String browser, String testname) throws IOException {
		// Create soft assert object
		SoftAssert softassert = new SoftAssert();
		test = extent.createTest(testname);
		test.log(Status.INFO, "Starting execution of chrome test case");
		// calling start browser from browser factory
		WebDriver driver = BrowserFactory.StartBrowser(browser, "https://opensource-demo.orangehrmlive.com");
		test.log(Status.INFO, "Started the browser");
		WebUtils.takeSnapshot(driver, "target/screenshots/test1.png");
		LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);
		test.pass("Navigated to HRM website login page");
		// Verify element visible on page
		String login_button_loc = "//input[@id='btnLogin']";
		WebElement loginElement = driver.findElement(By.xpath(login_button_loc));
		softassert.assertEquals(true,loginElement.isDisplayed());
		// Verify element present on page
		Boolean element_status = WebUtils.verifyElementPresent(driver, login_button_loc);
		System.out.println("element present status ===" + element_status);
		softassert.assertTrue(element_status);
		test.log(Status.INFO, "Entering user credentials");
		login_page.loginHRM_New("Admin", "admin123");
		WebUtils.takeSnapshot(driver, "target/screenshots/test2.png");
		// Soft Assertions
		String getActualTitle = driver.getTitle();
		Boolean verifyTitle = driver.getTitle().equalsIgnoreCase("OrangeHRM");
		// assertEqual
		softassert.assertEquals(getActualTitle, "OrangeHRM");  //pass
		// assertNotEqual
		softassert.assertNotEquals(getActualTitle, "AppleHRM"); //pass
		// assertNull
		softassert.assertNull(verifyTitle); // failure
		// assertNotNull
		softassert.assertNotNull(verifyTitle);  //pass
		// assertTrue
		softassert.assertTrue(true); //pass
		// assertFalse
		softassert.assertFalse(true);  //fail
		// call this after adding all assertions
		test.pass("Login to HRM PASS");
		driver.quit();
		test.pass("Completed the chrome test case");
		softassert.assertAll();
	}

	@AfterMethod
	public void tearDown() {
		extent.flush(); // Instruct extent reports to write the test info to the destination
	}
}
