package com.tests.extentReports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.scuba.helper.BrowserFactory;
import com.scuba.helper.ExtentReportManager;
import com.tests.pages.LoginPageNew;

/*
 * ExtentReport - logger style reporting library for selenium automation
 * Why? - It will add info for test cases, screenshots. tags etc..
 * Recommended to have single instance of extent reports
 */

public class AccountTest {
	
	public static ExtentReports extent;
	public static ExtentTest test;
	public static ExtentSparkReporter spark;
	
	@BeforeMethod
	public void setUp() {	
		extent = ExtentReportManager.getReports();	
		test = extent.createTest("Account Test");	
	}

	@Test
	public void account() {
		test.log(Status.INFO, "Starting execution of accounttest case");
		// calling start browser from browser factory		
		WebDriver driver = BrowserFactory.StartBrowser("chrome", "https://opensource-demo.orangehrmlive.com");	
		test.log(Status.INFO, "Started the browser");
		LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);	
		test.pass("Navigated to HRM website login page");
		test.log(Status.INFO, "Entering user credentials");
		login_page.loginHRM_New("Admin", "admin123");
		test.pass("Login to HRM PASS");
		driver.quit();
		test.pass("Completed the account test case");		
	}
	
	@AfterMethod
	public void tearDown() {
		extent.flush(); // Instruct extent reports to write the test info to the destination
	}
		
	}
	


	

